/*
 *  Copyright (c) 2017 Suprema Co., Ltd. All Rights Reserved.
 * 
 *  This software is the confidential and proprietary information of 
 *  Suprema Co., Ltd. ("Confidential Information").  You shall not
 *  disclose such Confidential Information and shall use it only in
 *  accordance with the terms of the license agreement you entered into
 *  with Suprema.
 */

#ifndef __UNIFINGERIDENTIFY_H__
#define __UNIFINGERIDENTIFY_H__

#ifdef __cplusplus
extern "C" 
{
#endif

unsigned char UF_IdentifyMsgCallback( BYTE errCode );

#ifdef __cplusplus
}
#endif

#endif
